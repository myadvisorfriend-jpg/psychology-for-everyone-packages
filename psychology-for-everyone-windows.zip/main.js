const { app, BrowserWindow } = require("electron");
const path = require("path");
function create() {
  const win = new BrowserWindow({ width: 1100, height: 800, title: "Psychology for Everyone" });
  win.loadFile(path.join(__dirname, "www", "index.html"));
}
app.whenReady().then(create);
app.on("window-all-closed", () => app.quit());
