# Windows

1. Install Node.js 20 or newer on Windows.
2. Open a terminal in this folder.
3. Run `npm install` then `npm start`. A window opens the offline book.
4. To make an installer: `npm run dist`. The installer appears under `dist`. Code signing is not configured. Windows SmartScreen will warn until you buy a certificate and sign the exe.
5. Microsoft Store submission is a separate Partner Center process. This zip is not a Store package.
6. Electron was not installed or launched in the environment that packed this zip.

The book is in the `www` folder. Tests in the app are marked on the computer, not on a server.
