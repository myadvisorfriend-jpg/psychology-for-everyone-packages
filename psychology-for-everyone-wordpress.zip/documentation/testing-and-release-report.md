# Testing report

Built in an environment without PHP, MySQL, Android Studio, or Xcode. Nothing below is marked passed unless it was actually run.

| Check | Status | Note |
| --- | --- | --- |
| WordPress plugin activation | Not tested | PHP is not installed in the build environment. |
| Theme activation, all ten | Not tested | Same reason. Source files are generated and follow the theme header format. |
| Demo import | Not tested | JSON files are included. Import was not executed. |
| Book reading in the living web preview | Passed | Home and a chapter page returned the book text in the preview app. |
| Server-side scoring in the preview | Not re-checked in a browser after packaging | The preview scores through a server function. Confirm a paper yourself in the preview. |
| Razorpay sandbox | Not tested | No merchant keys. |
| PayPal sandbox | Not tested | No merchant keys. Capture flow is documented, not executed. |
| Email delivery | Not tested | No mail server. |
| Android compile | Not tested | Project source only. |
| iOS compile | Not tested | Needs a Mac and Xcode. |
| Windows Electron launch | Not tested | Dependencies were not installed into the zip. |
| Accessibility audit | Not tested | Keyboard labels exist in the preview. No formal audit. |
| Backup and restore | Not tested | Instructions only. |

Do not describe this package as store-ready or payment-live.
