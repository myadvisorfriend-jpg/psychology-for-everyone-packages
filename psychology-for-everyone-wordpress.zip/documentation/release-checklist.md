# Release checklist

- [ ] Plugin zip uploads on a staging WordPress.
- [ ] Each theme activates and still shows chapters.
- [ ] Import once, read three chapters, search a word you know is in the book.
- [ ] Score a chapter test and compare one answer with the book.
- [ ] Razorpay test payment and a rejected fake webhook.
- [ ] PayPal sandbox only after you finish the capture call.
- [ ] SMTP test to the contribution address.
- [ ] Amazon links still blank or really yours.
- [ ] Privacy page reviewed.
- [ ] Backup tested.
- [ ] Phone layout checked.
- [ ] Only then replace test payment keys.
