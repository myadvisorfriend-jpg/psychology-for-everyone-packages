# Install Psychology for Everyone on WordPress

This package is source code. It is not already hosted. Work on a copy of the site first if you already have a live site.

## What you need

- A domain name.
- Hosting that runs WordPress.
- PHP 8.1 or newer.
- MySQL or MariaDB.
- HTTPS, which most hosts turn on with a free certificate.

## Install WordPress

1. In your host's panel, create a site and install WordPress. Many hosts have a button named "Install WordPress".
2. Open `https://your-domain/wp-admin` and sign in.

## Install the learning plugin

1. In the dashboard, open Plugins → Add New → Upload Plugin.
2. Choose `plugin/myadvisorfriend-learning-platform.zip` from this package.
3. Click Install Now, then Activate.
4. You should see a menu named MyAdvisorFriend.

## Install a theme

There are ten themes. They look different. The book stays the same if you switch.

1. Appearance → Themes → Add New → Upload Theme.
2. Choose one zip from the `themes` folder.
3. Install, then Activate.
4. Repeat for any other themes you want to keep available. Only one is active at a time.

## Import the book

1. Open MyAdvisorFriend.
2. Click "Import Psychology for Everyone demo".
3. Wait. The book is long. Do not close the tab.
4. Visit the public site. Volumes and chapters should be listed.

Importing again will add a second copy. Delete the old posts first if you need a clean import.

## Menus, homepage, logo

1. Appearance → Menus. Create a menu and assign it to the theme's primary location.
2. Add links for Home, the books archive, volumes, chapters, a search item, About, Buy, Reviews, Contact, and Appointments. Create ordinary Pages for the pages that are not books.
3. Appearance → Customize, if your host shows it, for the site title and logo. The themes use the site title.

## Email

1. In MyAdvisorFriend settings, the contribution notices address is `shivray.enterprises23@gmail.com`.
2. The public contact address is `myadvisorfriend@gmail.com`.
3. WordPress `wp_mail` uses the server's mail. Many hosts block it. Install a well-known SMTP plugin and send a test message before you rely on it.
4. Unpaid notes and verified payments are different. The plugin's first save is unpaid.

## Amazon, social, appointments

- Appointments link in the book: `https://myadvisorfriend.com`. Do not invent a calendar path.
- Leave Amazon fields blank until you have a real product page. The reader should see Coming soon rather than a fake link.
- Paste social URLs only for accounts you control.

## Payments

See `payment-setup-guide.md`. Do not paste live secret keys until a sandbox payment has been verified. Never put secrets in a theme file or in a public page.

## Before you announce the site

- Read a chapter on a phone.
- Submit a test and confirm the score.
- Send yourself a contribution in test mode.
- Turn on backups and HTTPS.
- Replace the draft privacy, terms, and refund text with text a lawyer has read.

## Updates

1. Back up files and the database.
2. Upload the new plugin zip. WordPress will offer to replace the current one.
3. Themes can be replaced the same way. Replacing a theme does not delete posts.

## If something breaks

- Plugin missing: chapters will not exist. Activate MyAdvisorFriend.
- White screen: ask the host for the PHP error log. Do not keep refreshing.
- Import timeout: ask the host to raise the PHP time limit, then import again after deleting partial posts.
- Mail not arriving: use SMTP. Check spam.
