# Razorpay and PayPal

No payment was taken while this package was built. You must connect your own merchant accounts.

## Rules that do not change

- Never store card numbers on WordPress.
- Secret keys stay in MyAdvisorFriend settings, which are stored in the database, not in the theme.
- A form submission is unpaid until the provider says the payment succeeded.
- Razorpay and PayPal do not support every currency in every country. Check your account.

## Razorpay test mode

1. Create a Razorpay account and open test mode.
2. Copy the test Key Id and Key Secret into MyAdvisorFriend settings.
3. Create a webhook pointing at `https://your-domain/wp-json/maf/v1/razorpay-webhook`.
4. Copy the webhook secret into the settings.
5. Send a test contribution. The plugin creates an order only when both keys are present. It does not show success merely because the form was posted.
6. Confirm the webhook signature check rejects a fake call.

## PayPal sandbox

PayPal buttons need your sandbox client id and secret. The plugin stores them. Completing a capture still requires the official PayPal checkout script on a page, using the client id only (never the secret) in the browser, then a server call you control to capture the order. Do not mark the contribution paid in the browser.

The endpoint included here records unpaid notes and can create a Razorpay order. PayPal capture is documented here because a full PayPal button was not executed against a sandbox in this build. Treat PayPal as configuration-ready, not as a tested live integration.

## Going live

1. Take a backup.
2. Replace test keys with live keys.
3. Make one small real payment and refund it using the provider's dashboard.
4. Write the refund window in your public refund page.
