# Security, privacy, backups

- The plugin checks `manage_options` and nonces on settings and import.
- Chapter text is escaped on import and passed through `wp_kses_post` when saved.
- Question answers are post meta on a private question type and are not part of the public chapter HTML.
- The scoring route returns the keyed letter only after a learner submits that item. Do not also print an answer list on a public page.
- Razorpay webhooks are accepted only when the HMAC signature matches. Duplicate payment ids are ignored for a day using a transient.
- Rate limiting beyond that is not included. Add a security plugin or a host firewall before a public launch.
- Contribution emails contain name, email, city, country, amount, and comments. They must not contain card data. The form does not ask for cards.
- Back up with your host or a backup plugin. Test a restore on a staging site once.
- Delete learner records from the Contributions and attempts screens when someone asks, and say so in the privacy page.
- This guide was not verified by a penetration test.
