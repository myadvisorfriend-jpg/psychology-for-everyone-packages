# Developer notes

Content model: WordPress custom post types `maf_book`, `maf_volume`, `maf_chapter`, `maf_question`, `maf_contribution`, `maf_review`.

A chapter stores the source id, volume id, and reading minutes as post meta. Questions store the answer as private meta.

REST:

- `GET /wp-json/maf/v1/catalog`
- `POST /wp-json/maf/v1/score` with `{ "answers": [{"id": "q-1-1", "choice": "d"}] }`
- `POST /wp-json/maf/v1/contribute`
- `POST /wp-json/maf/v1/razorpay-webhook`

Themes must not copy this logic. They display posts. Switching themes must not delete posts. The plugin does not delete posts on deactivation.

The answer key shipped in `includes/answers.php` is the key printed in the book. Editing a question in WordPress after import is the right way to change a key. Do not expose `answers.php` by linking to it. Direct HTTP requests to PHP files in the plugin execute the file, which returns nothing to the browser if it is only a function.

Database: this version uses posts and post meta, not a custom table. Attempts are not stored unless you extend `maf_rest_score`. That gap is intentional to avoid pretending a results archive exists before you decide retention.

Search uses WordPress search. It will find chapter titles and body text.
