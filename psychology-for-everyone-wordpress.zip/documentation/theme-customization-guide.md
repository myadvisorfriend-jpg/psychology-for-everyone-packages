# Theme customization

Ten themes are installed separately. They do not contain the book.

| Zip | Look |
| --- | --- |
| 01-classic-book-library | Cream paper, centred masthead, serif reading column |
| 02-modern-learning-academy | Sidebar campus |
| 03-premium-knowledge-centre | Night background, gold titles |
| 04-minimal-reading-room | Narrow column, little chrome |
| 05-interactive-learning-hub | Warm rounded cards |
| 06-examination-academy | Blue test-first frame |
| 07-video-learning-studio | Dark screening room |
| 08-audio-knowledge-library | Plum listening theme |
| 09-research-discovery-portal | Dense index on archive paper |
| 10-pay-what-you-think-is-fair-library | Open page with gift language |

Colours live at the top of each `style.css` as variables (`--bg`, `--fg`, `--primary`). Change those. Do not copy scoring code into a theme.

Menus, widgets, and the Customizer logo are the supported way to change the frame. The book is edited under Chapters in the dashboard.
