The book JSON used by the importer is inside the plugin zip at demo-content/. Import it from the MyAdvisorFriend menu after activation.
