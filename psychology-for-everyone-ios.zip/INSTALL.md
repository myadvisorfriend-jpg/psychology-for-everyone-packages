# iPhone, iPad, and Mac App Store

Apple will only build this on a Mac.

1. Install Xcode from the Mac App Store.
2. Install XcodeGen (`brew install xcodegen`) and, in this folder, run `xcodegen generate`. That creates `PsychologyForEveryone.xcodeproj` from `project.yml` and includes the `www` reader.
3. Open the project. Set the signing team to your Apple Developer account. The bundle id is `com.myadvisorfriend.psychology`. Change it if you do not own that id.
4. Choose an iPhone, iPad, or My Mac destination and press Run.
5. For the App Store: Product → Archive → Distribute App. You need a paid Apple Developer membership.
6. In App Store Connect, create the iOS app. Mac distribution of the same project needs a Mac target; this project is an iOS app that also runs on Apple silicon Macs as "Designed for iPad" if you enable that in App Store Connect. A separate Mac Catalyst checkbox can be turned on in Xcode (General → Mac Catalyst) if you want a native Mac binary. Do that on the Mac. It was not switched on here.
7. Privacy nutrition labels: the offline reader does not create an account. Test answers stay on the device.
8. This project was not compiled here. There is no App Store binary in this zip.

The book text is inside `PsychologyForEveryone/www`.
