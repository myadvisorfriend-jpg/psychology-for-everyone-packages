import SwiftUI
@main
struct PsychologyApp: App {
    var body: some Scene {
        WindowGroup { ReaderView() }
    }
}
