
const app = document.getElementById("app");
let catalog = null;

async function load() {
  const res = await fetch("data/catalog.json");
  catalog = await res.json();
  showVolumes();
}

function showVolumes() {
  app.innerHTML = "<h2>Volumes</h2>" + catalog.volumes.map((v) =>
    `<article class="card"><h3>${v.number ? "Volume " + v.number + ". " : ""}${v.title}</h3><p class="muted">${v.blurb}</p><button data-vol="${v.id}" type="button">Open</button></article>`
  ).join("");
  app.querySelectorAll("[data-vol]").forEach((btn) => btn.addEventListener("click", () => showVolume(btn.dataset.vol)));
}

function showVolume(id) {
  const volume = catalog.volumes.find((v) => v.id === id);
  const items = volume.chapterIds.map((cid) => catalog.chapters.find((c) => c.id === cid)).filter(Boolean);
  app.innerHTML = `<p><button type="button" id="back">All volumes</button></p><h2>${volume.title}</h2>` +
    items.map((c) => `<p><button type="button" data-ch="${c.id}">${c.title}</button> <span class="muted">${c.minutes} min</span></p>`).join("");
  document.getElementById("back").onclick = showVolumes;
  app.querySelectorAll("[data-ch]").forEach((btn) => btn.addEventListener("click", () => showChapter(btn.dataset.ch)));
}

async function showChapter(id) {
  const res = await fetch("data/chapters/" + id + ".json");
  const chapter = await res.json();
  const html = chapter.sections.map((s) => {
    const h = s.heading ? `<h3>${escapeHtml(s.heading)}</h3>` : "";
    const blocks = s.blocks.map((b) => b.type === "li" ? `<li>${escapeHtml(b.text)}</li>` : `<p>${escapeHtml(b.text)}</p>`).join("");
    return h + blocks;
  }).join("");
  app.innerHTML = `<p><button type="button" id="back">Back</button></p><p class="muted">${escapeHtml(chapter.numberLabel)} · ${chapter.minutes} min</p><h2>${escapeHtml(chapter.title)}</h2>` +
    (chapter.safety ? `<p class="card">If someone may be in immediate danger, contact local emergency services. In India, Tele-MANAS is 14416. This app is not a crisis service.</p>` : "") +
    `<article>${html}</article>`;
  document.getElementById("back").onclick = () => showVolume(chapter.volumeId);
}

function escapeHtml(value) {
  return String(value).replace(/[&<>]/g, (ch) => ({ "&": "&", "<": "<", ">": ">" }[ch]));
}

document.getElementById("tab-read").onclick = () => catalog && showVolumes();
document.getElementById("tab-search").onclick = async () => {
  const index = await (await fetch("data/search-index.json")).json();
  app.innerHTML = `<label>Search<br><input id="q" style="width:100%"></label><div id="hits"></div>`;
  const input = document.getElementById("q");
  input.oninput = () => {
    const query = input.value.trim().toLowerCase();
    const hits = query.length < 2 ? [] : index.filter((d) => (d.title + " " + d.text).toLowerCase().includes(query)).slice(0, 20);
    document.getElementById("hits").innerHTML = hits.map((h) => `<p><button type="button" data-ch="${h.id}">${escapeHtml(h.title)}</button></p>`).join("") || `<p class="muted">${query.length < 2 ? "Type two letters." : "No matches."}</p>`;
    document.querySelectorAll("#hits [data-ch]").forEach((btn) => btn.addEventListener("click", () => showChapter(btn.dataset.ch)));
  };
};
document.getElementById("tab-test").onclick = async () => {
  const bank = await (await fetch("data/questions.json")).json();
  const key = await (await fetch("data/answer-key.json")).json();
  const sample = bank.questions.filter((q) => q.chapterNum === 1);
  app.innerHTML = `<h2>Chapter 1 check</h2><p class="muted">Marked on this device. The WordPress site marks on the server. This is not a diagnosis.</p>` +
    sample.map((q) => `<fieldset class="card"><legend>${escapeHtml(q.stem)}</legend>${q.options.map((o) => `<label><input type="radio" name="${q.id}" value="${o.id}"> (${o.id}) ${escapeHtml(o.text)}</label><br>`).join("")}</fieldset>`).join("") +
    `<button type="button" id="mark">Mark</button><p id="score"></p>`;
  document.getElementById("mark").onclick = () => {
    let correct = 0;
    sample.forEach((q) => {
      const chosen = app.querySelector(`input[name="${q.id}"]:checked`);
      if (chosen && chosen.value === key[q.id]) correct += 1;
    });
    document.getElementById("score").textContent = `${correct} / ${sample.length}. Re-read the chapter for any miss.`;
  };
};
load();
