<?php if (!defined('ABSPATH')) { exit; } ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class('cards'); ?>>
<?php wp_body_open(); ?>
<div class="layout cards">

<div>
<header class="site-header"><div class="wrap">
<p class="kicker">A Mental Well Being Series</p>
<a class="site-title" href="<?php echo esc_url(home_url('/')); ?>">Interactive Learning Hub</a>
<nav class="nav" aria-label="Primary"><?php wp_nav_menu(array('theme_location' => 'primary', 'container' => false, 'fallback_cb' => 'maf_theme_fallback_menu')); ?></nav>
</div></header>
<main class="wrap">
