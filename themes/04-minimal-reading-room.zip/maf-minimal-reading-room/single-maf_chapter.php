<?php
if (!defined('ABSPATH')) { exit; }
get_header();
while (have_posts()) {
    the_post();
    echo '<article class="card reader">';
    echo '<p>' . esc_html(get_post_meta(get_the_ID(), '_maf_minutes', true)) . ' min</p>';
    echo '<h1>' . esc_html(get_the_title()) . '</h1>';
    the_content();
    echo '<p>This page is education, not a diagnosis.</p>';
    echo '</article>';
}
get_footer();
