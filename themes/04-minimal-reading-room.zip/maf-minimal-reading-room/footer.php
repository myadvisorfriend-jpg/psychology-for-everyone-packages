<?php if (!defined('ABSPATH')) { exit; } ?>
</main>
<footer class="wrap site-footer">
<p>Psychology for Everyone is general education, not medical advice. Questions: <a href="mailto:myadvisorfriend@gmail.com">myadvisorfriend@gmail.com</a>. Appointments: <a href="https://myadvisorfriend.com">myadvisorfriend.com</a>.</p>
<?php wp_footer(); ?>
</div></div>
</body></html>
