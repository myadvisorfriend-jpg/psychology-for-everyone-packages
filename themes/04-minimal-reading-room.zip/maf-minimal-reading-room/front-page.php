<?php
if (!defined('ABSPATH')) { exit; }
get_header();
if (have_posts()) {
    while (have_posts()) {
        the_post();
        echo '<article class="card">';
        echo '<h1>' . esc_html(get_the_title()) . '</h1>';
        the_content();
        echo '</article>';
    }
} else {
    echo '<article class="card"><h1>Psychology for Everyone</h1><p>Activate the MyAdvisorFriend plugin and import the demo book. Then assign a menu.</p></article>';
}
$volumes = get_posts(array('post_type' => 'maf_volume', 'posts_per_page' => 20, 'orderby' => 'menu_order', 'order' => 'ASC'));
if ($volumes) {
    echo '<div class="grid">';
    foreach ($volumes as $volume) {
        echo '<a class="card" href="' . esc_url(get_permalink($volume)) . '"><strong>' . esc_html($volume->post_title) . '</strong><p>' . esc_html(wp_trim_words($volume->post_content, 24)) . '</p></a>';
    }
    echo '</div>';
}
get_footer();

function maf_theme_fallback_menu() {
    $links = array(
        '/' => 'Home',
        '/books/' => 'Full Book',
        '/volumes/' => 'Volumes',
        '/chapters/' => 'Chapters',
        '/videos/' => 'Videos',
        '/audios/' => 'Audios',
        '/?s=' => 'Search',
    );
    foreach ($links as $href => $label) {
        echo '<a href="' . esc_url(home_url($href)) . '">' . esc_html($label) . '</a>';
    }
}
