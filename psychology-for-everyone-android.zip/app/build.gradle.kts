plugins { id("com.android.application") }
android {
    namespace = "com.myadvisorfriend.psychology"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.myadvisorfriend.psychology"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
}
dependencies {}
