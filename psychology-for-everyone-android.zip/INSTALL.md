# Android

This is a project, not a Play Store listing.

1. Install Android Studio (current stable) on your computer.
2. Open the `android` folder. Let Studio download the Android Gradle plugin and SDK 35. The first open creates or uses the wrapper.
3. The book is in `app/src/main/assets/www`. The app opens that offline reader. It does not require the website to be online.
4. Run on a phone or emulator. Read a chapter, search, and try the Chapter 1 check.
5. To publish: Build → Generate Signed App Bundle. Create a keystore and store the password somewhere safe. You cannot recover it.
6. In Play Console, create the app, upload the AAB, complete the content rating, privacy policy URL, and store listing.
7. This build was not compiled here. If Studio reports a Gradle version mismatch, accept its suggested upgrade.

Scoring inside the offline app happens on the device. The WordPress site scores on the server. Say that in your store description if you mention tests.

Do not add crisis features that collect someone's distress and send it to an unattended inbox.
