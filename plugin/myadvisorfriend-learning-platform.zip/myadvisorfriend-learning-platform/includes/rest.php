<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('rest_api_init', function () {
    register_rest_route('maf/v1', '/catalog', array('methods' => 'GET', 'callback' => 'maf_rest_catalog', 'permission_callback' => '__return_true'));
    register_rest_route('maf/v1', '/score', array('methods' => 'POST', 'callback' => 'maf_rest_score', 'permission_callback' => '__return_true'));
    register_rest_route('maf/v1', '/contribute', array('methods' => 'POST', 'callback' => 'maf_rest_contribute', 'permission_callback' => '__return_true'));
    register_rest_route('maf/v1', '/razorpay-webhook', array('methods' => 'POST', 'callback' => 'maf_rest_razorpay', 'permission_callback' => '__return_true'));
});

function maf_rest_catalog() {
    $chapters = get_posts(array('post_type' => 'maf_chapter', 'posts_per_page' => 200, 'orderby' => 'menu_order', 'order' => 'ASC'));
    $out = array();
    foreach ($chapters as $chapter) {
        $out[] = array(
            'id' => $chapter->ID,
            'title' => $chapter->post_title,
            'excerpt' => $chapter->post_excerpt,
            'link' => get_permalink($chapter),
            'volume' => get_post_meta($chapter->ID, '_maf_volume_id', true),
        );
    }
    return array('chapters' => $out);
}

function maf_rest_score($request) {
    $params = $request->get_json_params();
    $rows = isset($params['answers']) && is_array($params['answers']) ? $params['answers'] : array();
    $correct = 0;
    $incorrect = 0;
    $unanswered = 0;
    $items = array();
    foreach ($rows as $row) {
        $qid = isset($row['id']) ? sanitize_text_field($row['id']) : '';
        $choice = isset($row['choice']) ? strtolower(sanitize_text_field($row['choice'])) : '';
        $posts = get_posts(array('post_type' => 'maf_question', 'meta_key' => '_maf_qid', 'meta_value' => $qid, 'posts_per_page' => 1));
        if (!$posts) {
            continue;
        }
        $answer = get_post_meta($posts[0]->ID, '_maf_answer', true);
        if ($choice === '') {
            $unanswered++;
            $ok = false;
        } elseif ($choice === $answer) {
            $correct++;
            $ok = true;
        } else {
            $incorrect++;
            $ok = false;
        }
        $items[] = array('id' => $qid, 'ok' => $ok, 'correct' => $answer, 'choice' => $choice, 'chapter' => get_post_meta($posts[0]->ID, '_maf_chapter', true));
    }
    $total = count($items);
    $settings = maf_settings();
    $percent = $total ? (int) round(($correct / $total) * 100) : 0;
    return array(
        'total' => $total,
        'correct' => $correct,
        'incorrect' => $incorrect,
        'unanswered' => $unanswered,
        'percent' => $percent,
        'passed' => $percent >= (int) $settings['pass_mark'],
        'passMark' => (int) $settings['pass_mark'],
        'items' => $items,
        'note' => 'This score is recall of the published items. It is not a diagnosis.',
    );
}

function maf_rest_contribute($request) {
    $p = $request->get_json_params();
    $amount = isset($p['amount']) ? (float) $p['amount'] : 0;
    $email = isset($p['email']) ? sanitize_email($p['email']) : '';
    $consent = !empty($p['consent']);
    if ($amount <= 0 || !$email || !$consent) {
        return new WP_Error('maf_invalid', 'Amount, email, and consent are required.', array('status' => 400));
    }
    $id = wp_insert_post(array(
        'post_type' => 'maf_contribution',
        'post_status' => 'private',
        'post_title' => 'Unpaid note ' . gmdate('c'),
    ));
    update_post_meta($id, '_maf_status', 'unpaid');
    update_post_meta($id, '_maf_amount', $amount);
    update_post_meta($id, '_maf_currency', sanitize_text_field($p['currency'] ?? 'INR'));
    update_post_meta($id, '_maf_name', sanitize_text_field($p['name'] ?? ''));
    update_post_meta($id, '_maf_email', $email);
    update_post_meta($id, '_maf_city', sanitize_text_field($p['city'] ?? ''));
    update_post_meta($id, '_maf_country', sanitize_text_field($p['country'] ?? ''));
    update_post_meta($id, '_maf_review', sanitize_textarea_field($p['review'] ?? ''));
    update_post_meta($id, '_maf_suggestions', sanitize_textarea_field($p['suggestions'] ?? ''));
    $settings = maf_settings();
    $body = "Unpaid feedback. This is not a payment.\nAmount: {$amount}\nEmail: {$email}\n";
    wp_mail($settings['contribution_email'], 'Unpaid reader note', $body);
    $provider = sanitize_text_field($p['provider'] ?? '');
    if ($provider === 'razorpay' && $settings['razorpay_key_id'] && $settings['razorpay_key_secret']) {
        $response = wp_remote_post('https://api.razorpay.com/v1/orders', array(
            'headers' => array(
                'Authorization' => 'Basic ' . base64_encode($settings['razorpay_key_id'] . ':' . $settings['razorpay_key_secret']),
                'Content-Type' => 'application/json',
            ),
            'body' => wp_json_encode(array(
                'amount' => (int) round($amount * 100),
                'currency' => sanitize_text_field($p['currency'] ?? 'INR'),
                'receipt' => 'maf_' . $id,
            )),
            'timeout' => 20,
        ));
        if (is_wp_error($response)) {
            return array('status' => 'unpaid', 'id' => $id, 'message' => 'Order was not created. The note is saved as unpaid.');
        }
        $order = json_decode(wp_remote_retrieve_body($response), true);
        update_post_meta($id, '_maf_gateway_order', sanitize_text_field($order['id'] ?? ''));
        return array('status' => 'pending', 'id' => $id, 'order' => $order, 'keyId' => $settings['razorpay_key_id']);
    }
    return array(
        'status' => 'unpaid',
        'id' => $id,
        'message' => 'Saved as unpaid. Add Razorpay or PayPal keys before expecting a charge. A form submission is not a payment.',
    );
}

function maf_rest_razorpay($request) {
    $settings = maf_settings();
    $raw = $request->get_body();
    $signature = $request->get_header('x-razorpay-signature');
    if (!$settings['razorpay_webhook_secret'] || !$signature) {
        return new WP_Error('maf_webhook', 'Webhook secret is not configured.', array('status' => 400));
    }
    $expected = hash_hmac('sha256', $raw, $settings['razorpay_webhook_secret']);
    if (!hash_equals($expected, $signature)) {
        return new WP_Error('maf_webhook', 'Signature did not match.', array('status' => 400));
    }
    $payload = json_decode($raw, true);
    $event_id = sanitize_text_field($payload['payload']['payment']['entity']['id'] ?? '');
    if ($event_id && get_transient('maf_rzp_' . $event_id)) {
        return array('status' => 'duplicate');
    }
    if ($event_id) {
        set_transient('maf_rzp_' . $event_id, 1, DAY_IN_SECONDS);
    }
    $receipt = sanitize_text_field($payload['payload']['payment']['entity']['notes']['receipt'] ?? '');
    return array('status' => 'received', 'receipt' => $receipt);
}
