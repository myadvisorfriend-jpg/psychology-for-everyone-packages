<?php
if (!defined('ABSPATH')) {
    exit;
}

function maf_register_types() {
    $common = array('show_in_rest' => true, 'public' => true, 'show_ui' => true, 'has_archive' => true, 'supports' => array('title', 'editor', 'excerpt', 'page-attributes'));
    register_post_type('maf_book', array_merge($common, array('labels' => array('name' => 'Books', 'singular_name' => 'Book'), 'menu_icon' => 'dashicons-book', 'rewrite' => array('slug' => 'books'))));
    register_post_type('maf_volume', array_merge($common, array('labels' => array('name' => 'Volumes', 'singular_name' => 'Volume'), 'rewrite' => array('slug' => 'volumes'))));
    register_post_type('maf_chapter', array_merge($common, array('labels' => array('name' => 'Chapters', 'singular_name' => 'Chapter'), 'rewrite' => array('slug' => 'chapters'))));
    register_post_type('maf_question', array('labels' => array('name' => 'Questions', 'singular_name' => 'Question'), 'public' => false, 'show_ui' => true, 'show_in_rest' => false, 'supports' => array('title', 'editor')));
    register_post_type('maf_contribution', array('labels' => array('name' => 'Contributions', 'singular_name' => 'Contribution'), 'public' => false, 'show_ui' => true, 'show_in_rest' => false, 'supports' => array('title')));
    register_post_type('maf_review', array('labels' => array('name' => 'Reader notes', 'singular_name' => 'Reader note'), 'public' => true, 'show_ui' => true, 'show_in_rest' => true, 'supports' => array('title', 'editor')));
}
add_action('init', 'maf_register_types');

function maf_chapter_meta_box() {
    add_meta_box('maf_chapter_meta', 'Learning details', 'maf_chapter_meta_render', 'maf_chapter', 'side');
}
add_action('add_meta_boxes', 'maf_chapter_meta_box');

function maf_chapter_meta_render($post) {
    wp_nonce_field('maf_chapter_meta', 'maf_chapter_nonce');
    $fields = array('volume_id' => 'Volume id', 'minutes' => 'Minutes', 'objectives' => 'Objectives');
    foreach ($fields as $key => $label) {
        $val = get_post_meta($post->ID, '_maf_' . $key, true);
        echo '<p><label>' . esc_html($label) . '<br><input class="widefat" name="maf_' . esc_attr($key) . '" value="' . esc_attr($val) . '"></label></p>';
    }
}

function maf_save_chapter_meta($post_id) {
    if (!isset($_POST['maf_chapter_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['maf_chapter_nonce'])), 'maf_chapter_meta')) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    foreach (array('volume_id', 'minutes', 'objectives') as $key) {
        if (isset($_POST['maf_' . $key])) {
            update_post_meta($post_id, '_maf_' . $key, sanitize_text_field(wp_unslash($_POST['maf_' . $key])));
        }
    }
}
add_action('save_post_maf_chapter', 'maf_save_chapter_meta');
