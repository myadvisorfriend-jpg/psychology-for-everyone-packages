<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_post_maf_import_demo', function () {
    if (!current_user_can('manage_options')) {
        wp_die('You cannot import content.');
    }
    check_admin_referer('maf_import_demo', 'maf_import_nonce');
    $catalog_path = MAF_DIR . 'demo-content/catalog.json';
    $questions_path = MAF_DIR . 'demo-content/questions.json';
    if (!file_exists($catalog_path)) {
        wp_die('Demo catalog is missing from the plugin.');
    }
    $catalog = json_decode(file_get_contents($catalog_path), true);
    $book_id = wp_insert_post(array(
        'post_type' => 'maf_book',
        'post_status' => 'publish',
        'post_title' => sanitize_text_field($catalog['book']['title']),
        'post_content' => wp_kses_post($catalog['book']['tagline'] . ' — ' . $catalog['book']['author']),
    ));
    $volume_posts = array();
    foreach ($catalog['volumes'] as $volume) {
        $vid = wp_insert_post(array(
            'post_type' => 'maf_volume',
            'post_status' => 'publish',
            'post_title' => sanitize_text_field($volume['title']),
            'post_content' => wp_kses_post($volume['blurb']),
            'menu_order' => (int) $volume['number'],
        ));
        update_post_meta($vid, '_maf_volume_key', sanitize_text_field($volume['id']));
        update_post_meta($vid, '_maf_book_id', (int) $book_id);
        $volume_posts[$volume['id']] = $vid;
    }
    foreach ($catalog['chapters'] as $meta) {
        $file = MAF_DIR . 'demo-content/chapters/' . $meta['id'] . '.json';
        if (!file_exists($file)) {
            continue;
        }
        $chapter = json_decode(file_get_contents($file), true);
        $html = '';
        foreach ($chapter['sections'] as $section) {
            if (!empty($section['heading'])) {
                $level = max(2, min(4, (int) $section['level']));
                $html .= '<h' . $level . '>' . esc_html($section['heading']) . '</h' . $level . '>';
            }
            $items = '';
            $paras = '';
            foreach ($section['blocks'] as $block) {
                if ($block['type'] === 'li') {
                    $items .= '<li>' . esc_html($block['text']) . '</li>';
                } else {
                    $paras .= '<p>' . esc_html($block['text']) . '</p>';
                }
            }
            $html .= $paras;
            if ($items) {
                $html .= '<ul>' . $items . '</ul>';
            }
        }
        $pid = wp_insert_post(array(
            'post_type' => 'maf_chapter',
            'post_status' => 'publish',
            'post_title' => sanitize_text_field($chapter['title']),
            'post_excerpt' => sanitize_text_field($chapter['summary']),
            'post_content' => wp_kses_post($html),
            'menu_order' => (int) $chapter['index'],
        ));
        update_post_meta($pid, '_maf_volume_id', sanitize_text_field($chapter['volumeId']));
        update_post_meta($pid, '_maf_minutes', (int) $chapter['minutes']);
        update_post_meta($pid, '_maf_source_id', sanitize_text_field($chapter['id']));
        if (isset($volume_posts[$chapter['volumeId']])) {
            update_post_meta($pid, '_maf_volume_post', (int) $volume_posts[$chapter['volumeId']]);
        }
    }
    if (file_exists($questions_path)) {
        $bank = json_decode(file_get_contents($questions_path), true);
        foreach ($bank['questions'] as $q) {
            $qid = wp_insert_post(array(
                'post_type' => 'maf_question',
                'post_status' => 'publish',
                'post_title' => sanitize_text_field($q['stem']),
            ));
            update_post_meta($qid, '_maf_qid', sanitize_text_field($q['id']));
            update_post_meta($qid, '_maf_options', wp_json_encode($q['options']));
            update_post_meta($qid, '_maf_chapter', sanitize_text_field($q['chapterId']));
            update_post_meta($qid, '_maf_volume', sanitize_text_field($q['volumeId']));
            $answers = maf_answer_key();
            if (isset($answers[$q['id']])) {
                update_post_meta($qid, '_maf_answer', sanitize_text_field($answers[$q['id']]));
            }
        }
    }
    wp_safe_redirect(admin_url('admin.php?page=myadvisorfriend&imported=1'));
    exit;
});
