<?php
if (!defined('ABSPATH')) {
    exit;
}

function maf_default_settings() {
    return array(
        'contact_email' => 'myadvisorfriend@gmail.com',
        'contribution_email' => 'shivray.enterprises23@gmail.com',
        'appointments_url' => 'https://myadvisorfriend.com',
        'living_edition' => 'https://psychologyforeveryone.com',
        'pass_mark' => 60,
        'amazon_ebook' => '',
        'amazon_paperback' => '',
        'amazon_hardcover' => '',
        'social_facebook' => '',
        'social_instagram' => '',
        'social_youtube' => '',
        'social_linkedin' => '',
        'social_x' => '',
        'social_whatsapp' => '',
        'razorpay_key_id' => '',
        'razorpay_key_secret' => '',
        'razorpay_webhook_secret' => '',
        'paypal_client_id' => '',
        'paypal_secret' => '',
        'paypal_sandbox' => '1',
        'currency' => 'INR',
    );
}

function maf_settings() {
    $saved = get_option('maf_settings', array());
    return array_merge(maf_default_settings(), is_array($saved) ? $saved : array());
}

function maf_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    if (isset($_POST['maf_settings_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['maf_settings_nonce'])), 'maf_save_settings')) {
        $defaults = maf_default_settings();
        $next = array();
        foreach ($defaults as $key => $default) {
            $raw = isset($_POST[$key]) ? wp_unslash($_POST[$key]) : '';
            if (str_contains($key, 'url') || str_contains($key, 'amazon') || str_contains($key, 'social')) {
                $next[$key] = esc_url_raw($raw);
            } elseif ($key === 'pass_mark') {
                $next[$key] = max(50, min(80, (int) $raw));
            } elseif ($key === 'paypal_sandbox') {
                $next[$key] = empty($_POST[$key]) ? '0' : '1';
            } else {
                $next[$key] = sanitize_text_field($raw);
            }
        }
        update_option('maf_settings', $next);
        echo '<div class="updated"><p>Settings saved. Secret keys stay on the server.</p></div>';
    }
    $s = maf_settings();
    echo '<div class="wrap"><h1>MyAdvisorFriend</h1>';
    echo '<p>Switching the theme does not delete books, questions, or contribution records.</p>';
    echo '<form method="post">';
    wp_nonce_field('maf_save_settings', 'maf_settings_nonce');
    foreach (maf_default_settings() as $key => $default) {
        $type = str_contains($key, 'secret') ? 'password' : 'text';
        echo '<p><label>' . esc_html($key) . '<br><input class="regular-text" type="' . esc_attr($type) . '" name="' . esc_attr($key) . '" value="' . esc_attr((string) $s[$key]) . '"></label></p>';
    }
    submit_button('Save settings');
    echo '</form>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
    echo '<input type="hidden" name="action" value="maf_import_demo">';
    wp_nonce_field('maf_import_demo', 'maf_import_nonce');
    submit_button('Import Psychology for Everyone demo');
    echo '</form></div>';
}

function maf_admin_menu() {
    add_menu_page('MyAdvisorFriend', 'MyAdvisorFriend', 'manage_options', 'myadvisorfriend', 'maf_settings_page', 'dashicons-welcome-learn-more', 26);
}
add_action('admin_menu', 'maf_admin_menu');
