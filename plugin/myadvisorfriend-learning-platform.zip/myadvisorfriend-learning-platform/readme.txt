=== MyAdvisorFriend Learning Platform ===
Stable tag: 1.0.0
Requires PHP: 8.1

Books, tests, and voluntary contributions for Psychology for Everyone.
