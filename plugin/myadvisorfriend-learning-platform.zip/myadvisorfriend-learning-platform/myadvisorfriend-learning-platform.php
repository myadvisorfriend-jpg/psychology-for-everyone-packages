<?php
/**
 * Plugin Name: MyAdvisorFriend Learning Platform
 * Description: Books, volumes, chapters, quizzes, search, and voluntary contributions. Presentation stays in the theme.
 * Version: 1.0.0
 * Requires at least: 6.4
 * Requires PHP: 8.1
 * Author: Satish Zope
 * License: GPL-2.0-or-later
 * Text Domain: myadvisorfriend
 */

if (!defined('ABSPATH')) {
    exit;
}

define('MAF_VERSION', '1.0.0');
define('MAF_FILE', __FILE__);
define('MAF_DIR', plugin_dir_path(__FILE__));

require_once MAF_DIR . 'includes/answers.php';
require_once MAF_DIR . 'includes/post-types.php';
require_once MAF_DIR . 'includes/settings.php';
require_once MAF_DIR . 'includes/importer.php';
require_once MAF_DIR . 'includes/rest.php';

register_activation_hook(__FILE__, function () {
    maf_register_types();
    flush_rewrite_rules();
    if (!get_option('maf_settings')) {
        update_option('maf_settings', maf_default_settings());
    }
});

register_deactivation_hook(__FILE__, function () {
    flush_rewrite_rules();
});
